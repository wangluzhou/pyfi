
def template1():
    pass

def template2():
    pass


templates = {
    "历史上牛市回调的持续时间": template1,
    "股市与债市相对配置价值比较": template2,
}

template_names = templates.keys()




