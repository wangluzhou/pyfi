# encoding: utf-8
import sqlite3
# 用户需要自己安装sqlite3
# 基于并购事件的债券定价模型
# 离线数据库bonds.db