# pyfi
# author：wangluzhou

将wind的WindPy接口导出的数据转换成pandas的dataframe格式，方便分析处理。
